﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WheelChair.Models
{
    public class UserModel
    {
        //bodyDimension
        public int RefId { get; set; }

        //LoanInformiation 
        public string LoanFormNo { get; set; }


    }
}

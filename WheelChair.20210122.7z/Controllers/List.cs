﻿namespace WheelChair.Controllers
{
    internal class List<T1, T2>
    {
        public List()
        {
        }
    }
}
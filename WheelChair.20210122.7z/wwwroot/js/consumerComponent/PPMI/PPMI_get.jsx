﻿import handleServerFeedback from '/js/shared/handleServerFeedback.js';
import serverComuunication from '/js/shared/serverComuunication.js';
import ReactTable from '/js/shared/ReactTableRevamp.jsx';

class InputContainer extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            'ppmi_list': [],
            filterStrA: "",
            selectedField: "",
            isSettingData: false,
            isFinalSettingDataReached: false,
            isSubmited: false,
            isSubmitSuccess: false,
            lastSubmittedForm: "",
            submitMessage: ''
        };

        this.editOneCard = this.editOneCard.bind(this);
    }
    handleStateManagement_General_ServerFeedback = (serverFeedback) => {
        return handleServerFeedback(serverFeedback).then((massaged_feedback) => {
            this.setState({ isSubmitSuccess: massaged_feedback.isSubmitSuccess, submitMessage: massaged_feedback.submitMessage, isSubmited: massaged_feedback.isSubmited });
            return massaged_feedback.content;
        }).catch(exx => {
            exx.submitMessage.then(x => this.setState({ submitMessage: x, isSubmitSuccess: exx.isSubmitSuccess, isSubmited: exx.isSubmited }));
            throw exx;
        });
    }
    gotoCreatePage() {
        var queryString = { "seatNo": this.props.pSeatNo, 'pageAction': 'create' };
        serverComuunication.handleInternalServerPageRedirect("PPMIPage/Edit", queryString);
    }
    editOneCard(e) {
        var queryString = {
            "id": [e],
            "pageAction": "update"
        };
        serverComuunication.handleInternalServerPageRedirect("PPMIPage/edit", queryString);
    }
    // returns a Promise
    async handleFormGetData(seatNo, controller) {
        let tmp = serverComuunication.handleServerCommunication_type4('GET', controller, '', { "seat_no": seatNo })
        this.handleStateManagement_General_ServerFeedback(tmp)
            .then((getData) => {
                this.setState({ isSubmitSuccess: true, submitMessage: '', isSubmited: true, ppmi_list: JSON.parse(getData) });
            }).catch((response) => {
                this.setState({ isSubmitSuccess: false, submitMessage: 'Error occured:' + response, isSubmited: false });
                throw response;
            });
    }
    async componentDidMount() {
        if (this.props.pSeatNo)
            await this.handleFormGetData(this.props.pSeatNo, "PPMI_list");
        else
            await this.handleFormGetData(this.props.pSeatNo, "PPMI");
    }
    handleSubmitItems2local(ele) {
        // need to have full order item then add items
        if ((this.state.Work_Order_InputForm.OrderDate === '' && this.state.Work_Order_InputForm.SeatNo !== undefined) ||
            (this.state.Work_Order_InputForm.SeatNo === '' && this.state.Work_Order_InputForm.OrderDate !== undefined) ||
            (this.state.Work_Order_InputForm.OrderDate === undefined && this.state.Work_Order_InputForm.SeatNo === undefined)) {
            alert('please input all order information first');
            return;
        }
        this.setState({ Work_Order_Items: this.state.Work_Order_Items.concat([ele]) }, () => console.log(this.state.Work_Order_Items));
    }
    gotoPage() {
        var queryString = {};
        if (this.props.pSeatNo)
            queryString = { "seatNo": this.props.pSeatNo, 'pageAction': 'update' };
        else
            queryString = { 'pageAction': 'create' };
        serverComuunication.handleInternalServerPageRedirect(" ClientSearch/clientInformation", queryString);
    }
    render() {
        return (
            <div className="formWheelChair">

                <div className="flexDiv">
                    &nbsp;  <h1>PPMI</h1><br />
                    <input type="button" value="Back to client information" onClick={() => this.gotoPage()} />

                </div>
                <br />
                <input type="button" value="Create New PPMI" onClick={() => this.gotoCreatePage()} />

                {this.state.isSubmitSuccess && this.state.isSubmited && this.state.ppmi_list.length == 0 && <div> No PPMI records found </div>}


                {this.state.ppmi_list.length > 0 && <ReactTable headerList={Object.keys(this.state.ppmi_list[0])} data={this.state.ppmi_list} hiddenFields={"PpmiRegNo"} filterStr={this.state.filterStrA} selectedField={this.state.selectedField}>
                    <button handler={this.editOneCard} uni_key="PpmiRegNo" display_string="Edit" css_class_name="reactTbBtn" />
                </ReactTable>}

            </div>
        );
    }
}
ReactDOM.render(<InputContainer pAction={qAction} pSeatNo={qSeatNo} pWorkingForm={qWorkingForm} />, document.getElementById('contentForm'));
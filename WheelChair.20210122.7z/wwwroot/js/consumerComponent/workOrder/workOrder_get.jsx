import handleServerFeedback from '/js/shared/handleServerFeedback.js';
import serverComuunication from '/js/shared/serverComuunication.js';
import ReactTable from '/js/shared/ReactTableRevamp.jsx'; 

class InputContainer extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            'work_order_list': [],
            isSettingData: false,
            isFinalSettingDataReached: false,
            isSubmited: false,
            isSubmitSuccess: false,
            lastSubmittedForm: "",
            submitMessage: ''
        };

        this.editOneCard = this.editOneCard.bind(this);
    }
    handleStateManagement_General_ServerFeedback = (serverFeedback) => {
        return handleServerFeedback(serverFeedback).then((massaged_feedback) => {
            this.setState({ isSubmitSuccess: massaged_feedback.isSubmitSuccess, submitMessage: massaged_feedback.submitMessage, isSubmited: massaged_feedback.isSubmited });
            return massaged_feedback.content;
        }).catch(exx => {
            exx.submitMessage.then(x => this.setState({ submitMessage: x, isSubmitSuccess: exx.isSubmitSuccess, isSubmited: exx.isSubmited }));
            throw exx;
        });
    } 
    gotoCreatePage() {
        var queryString = {
            "pageAction": "create"
        };
        serverComuunication.handleInternalServerPageRedirect("WorkOrderPage", queryString);
    }
    editOneCard(e) {
        var queryString = {
            "id": [e],
            "pageAction": "update"
        };
        serverComuunication.handleInternalServerPageRedirect("WorkOrderPage/edit", queryString);
    }
    gotoPage() {
        var queryString = {};
        if (this.props.pSeatNo)
            queryString = { "seatNo": this.props.pSeatNo, 'pageAction': 'update' };
        else
            queryString = { 'pageAction': 'create' };
        serverComuunication.handleInternalServerPageRedirect(" ClientSearch/clientInformation", queryString);
    }
    createNewWorkOrder() {
        var queryString = {};
        queryString = { "seatNo": this.props.pSeatNo, 'pageAction': 'create' };
        serverComuunication.handleInternalServerPageRedirect(" WorkOrderPage/Edit", queryString);
    }
    // returns a Promise
    async handleFormGetData(seatNo, controller) {
        let tmp = serverComuunication.handleServerCommunication_type4('GET', controller, '', { "seat_no": seatNo });
        this.handleStateManagement_General_ServerFeedback(tmp)  
            .then((getData) => {
                this.setState({ isSubmitSuccess: true, submitMessage: '', isSubmited: true, work_order_list: JSON.parse(getData) });
            }).catch((response) => {
                console.log(response);
                this.setState({ isSubmitSuccess: false, submitMessage: 'Error occured:' + response, isSubmited: false });
            });
    }
    async componentDidMount() {
        if (this.props.pSeatNo)
            await this.handleFormGetData(this.props.pSeatNo, "Work_order_list");
        else
            await this.handleFormGetData(this.props.pSeatNo, "Work_Order");
    }
    render() {
        return (
            <div className="formWheelChair">
                <div className="flexDiv">
                    &nbsp; <h1>Work orders</h1><br />
                    <button onClick={() => this.gotoPage()} className="">Back to client informaiton</button>
                </div>

                <br />
                <button onClick={() => this.createNewWorkOrder()} className="">New Work Order</button>

                {this.state.isSubmitSuccess && this.state.isSubmited && this.state.work_order_list.length == 0 && <div> No work order information found </div>}

                {this.state.work_order_list.length > 0 &&
                    <ReactTable headerList={Object.keys(this.state.work_order_list[0])} hiddenFields="" data={this.state.work_order_list}  >
                        <button handler={this.editOneCard} uni_key="OrderNo" display_string="Edit" css_class_name="reactTbBtn" />
                    </ReactTable>}

            </div>
        );
    }
}
ReactDOM.render(<InputContainer pAction={qAction} pSeatNo={qSeatNo} pWorkingForm={qWorkingForm} />, document.getElementById('contentForm'));

﻿import FilterMe from '/js/shared/FilterMe.jsx'; 
import serverComuunication from '/js/shared/serverComuunication.js';
import HandleAfterSubmit from '/js/shared/HandleAfterSubmit.jsx';
import ReactTable from '/js/shared/ReactTableRevamp.jsx';
import handleServerFeedback from '/js/shared/handleServerFeedback.js';
class DisplayContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            selectedField: "",
            fields: [],
            filterStrA: "",
            viewName: "Loan_record",
            isSubmited: false,
            isSubmitSuccess: false,
            submitMessage: ''
        };
        this.loadDataFromServer = this.loadDataFromServer.bind(this);
        this.loadSingleLoanFromServer = this.loadSingleLoanFromServer.bind(this); 
    } 
    async handleStateManagement_General_ServerFeedback (serverFeedback) {
        return handleServerFeedback(serverFeedback).then((massaged_feedback) => {
            this.setState({ isSubmitSuccess: massaged_feedback.isSubmitSuccess, submitMessage: massaged_feedback.submitMessage, isSubmited: massaged_feedback.isSubmited });
            return massaged_feedback.content;
        }).catch(exx => {
            exx.submitMessage.then(x => this.setState({ submitMessage: x, isSubmitSuccess: exx.isSubmitSuccess, isSubmited: exx.isSubmited }));
            throw exx;
        });
    } 
    onFocus = () => {
        this.componentDidMount();
        window.removeEventListener("focus", this.onFocus)
    }
    async loadSingleLoanFromServer() {
        let tmp = serverComuunication.handleServerCommunication_type4('GET', 'Loan_information_list', '', { "seat_no": this.props.pSeat_number, "loanNumber": this.props.pLoan_number });
        this.handleStateManagement_General_ServerFeedback(tmp)
            .then((tmpData) => {
                let t = JSON.parse(tmpData);
                this.setState({ data: t });
                this.getFilterItemsList(t);
            }).catch((response) => console.log(response));
    }
    async loadDataFromServer(controller) {
        let tmp = serverComuunication.handleServerCommunication_type3('GET', controller);
        this.handleStateManagement_General_ServerFeedback(tmp)
            .then((tmpData) => {
                let t = JSON.parse(tmpData);
                this.setState({ data: t });
                this.getFilterItemsList(t);
            }).catch((response) => console.log(response));
    }
    getFilterItemsList(tmpData) {
        if (Array.isArray(tmpData) && tmpData.length) {
            let tmpElement = [];
            for (let prop in tmpData[0]) {
                //skip the date
                if (String(prop).toLowerCase().includes('date')) continue;
                tmpElement.push(prop);
            }
            let elementsFromApi = tmpElement.map(t => {
                return { value: t, display: t };
            });
            this.setState({
                fields: [{
                        value: "",
                        display: "(Select a filter)"
                    }].concat(elementsFromApi)
            });
        }
    } 
    editOneRow = (e) =>{
        var queryString = {
            "Id": [e],
            "pageAction": "update",
            "workingForm": "Loan_Record"
        };
        serverComuunication.handleInternalServerPageRedirect_newPage("LoanInformationPage", queryString)
    }
    setChangeFilter = (str, aField) => {
        this.setState({ filterStrA: str, selectedField: aField });
    }
    async componentDidMount() {
        if (this.props.pSeat_number)
            await this.loadSingleLoanFromServer();
        else
            await this.loadDataFromServer(this.state.viewName);
    }
    createNew(n) {
        let queryString = {
            "seatNo": [n],
            "workingForm": 'Loan_Record',
            "pageAction": "create"
        };
        serverComuunication.handleInternalServerPageRedirect("LoanInformationPage/index", queryString);
    }
    ////////////////////////////////////////////  
    gotoPreviousClientInformationPage() {
        var queryString = {};
        if (this.props.pSeat_number)
            queryString = { "seatNo": this.props.pSeat_number, 'pageAction': 'update' };
        else
            queryString = { 'pageAction': 'create' };
        serverComuunication.handleInternalServerPageRedirect(" ClientSearch/clientInformation", queryString);
    }
    render() {
        return (
            <div>
                <div className="flexDiv">
                    <div style={{ width: "80%" }}> &nbsp;  <h2>Loan Information</h2></div>
                    <div>  <button onClick={() => this.gotoPreviousClientInformationPage()} className="BackHeaderButtonStyle">Back to client information</button > </div>
                </div>
                <hr /> 
                <input type="button" value="New Loan Information" onClick={() => this.createNew(this.props.pSeat_number)} />
                <br /> 
                {this.state.isSubmitSuccess && this.state.isSubmited && this.state.data.length == 0 && <div> No loan information found </div>}
                {!this.state.isSubmitSuccess && <HandleAfterSubmit isSubmited={this.state.isSubmited} isSubmitSuccess={this.state.isSubmitSuccess} submitMessage={this.state.submitMessage} />}
                {this.state.data.length > 0 &&
                    <div className="filter">
                        <FilterMe changeFilter={this.setChangeFilter} itemList={this.state.fields} filterStr1={this.state.filterStrA} />
                    </div>}
                {this.state.data.length > 0 &&
                    <ReactTable headerList={Object.keys(this.state.data[0])} data={this.state.data} hiddenFields="Idno,TelOffice,Address,Witness,Rank" filterStr={this.state.filterStrA} selectedField={this.state.selectedField}>
                        <button handler={this.editOneRow} uni_key="LoanFormNo" display_string="Edit" css_class_name="reactTbBtn" />
                    </ReactTable>}
            </div>
        );
    }
}
ReactDOM.render(<DisplayContainer pLoan_number={qLoanNumber} pSeat_number={qSeatNo} />, document.getElementById('displayContent'));